


# TODO: Add these functions to my AirportAnalysis package tomorrow.

# Current Performance Metrics
# Return listings for which departure / arrivals actuals are already know.

get_flight_data <- function(flight_type, airport) {
  
  # Conditional to accomodate for either departures or arrivals
  if (flight_type == "departures") {
    data <- get_airlabs_api_response(key = "schedules", 
                                     parameter_name = "dep_iata", 
                                     parameter_value = airport) %>%
      distinct(arr_iata, dep_time, .keep_all = TRUE) %>%
      select(airline_iata, 
             dep_iata, dep_terminal, dep_time, dep_time_utc, dep_actual, 
             arr_iata, arr_terminal, arr_time, arr_time_utc, arr_actual,
             delayed) %>%
      filter(!is.na(dep_actual))
  } else if (flight_type == "arrivals") {
    data <- get_airlabs_api_response(key = "schedules", 
                                     parameter_name = "arr_iata", 
                                     parameter_value = airport) %>%
      distinct(arr_iata, dep_time, .keep_all = TRUE) %>%
      select(airline_iata, 
             dep_iata, dep_terminal, dep_time, dep_time_utc, dep_actual, 
             arr_iata, arr_terminal, arr_time, arr_time_utc, arr_actual,
             delayed) %>%
      filter(!is.na(arr_actual))
  } else {
    stop("Invalid flight type. Please specify 'departures' or 'arrivals'.")
  }
  
  data <- data %>%
    filter(!is.na(airline_iata)) %>%
    left_join(airports, by = c("arr_iata" = "iata_code")) %>%
    left_join(airlines, by = c("airline_iata" = "iata_code")) %>% 
    left_join(airports, by = c("dep_iata" = "iata_code")) %>%  
    # For categorising Domestic / International, use ifelse() for this process
    select(-c(country_code.x, country_code.y, name, icao_code)) %>%
    dplyr::rename("airport_name" = "name.x", "airline_name" = "name.y") %>%
    select(airline_name, airport_name, everything())
  
  # Convert dep_actual and dep_time to POSIXct format
  data$dep_actual <- as.POSIXct(data$dep_actual)
  data$dep_time <- as.POSIXct(data$dep_time)
  data$arr_actual <- as.POSIXct(data$arr_actual)
  data$arr_time <- as.POSIXct(data$arr_time)
  
  return(data)
}

# Usage
departures_dd <- get_flight_data("departures", "YYZ")
arrivals_dd <- get_flight_data("arrivals", "YYZ")


# Use the live flight data to calculate proportion of flights which are:
# 1. On Time
# 2. Within 15 Mins of scheduled time
# 3. Late

calculate_percentage <- function(data, terminal_type) {
  
  # Conditional
  if (terminal_type == "dep") {
    data <- data %>%
      rename("terminal" = "dep_terminal") %>%
      rename("actual" =  "dep_actual") %>%
      rename("time" = "dep_time")
  } else if (terminal_type == "arr") {
    data <- data %>%
      rename("terminal" = "arr_terminal")%>%
      rename("actual" =  "arr_actual") %>%
      rename("time" = "arr_time")
  }

  # Use dplyr::summarise and tidyr::pivot_longer
  percentage_df <- data %>%
    #group_by(terminal) %>%
    summarise(
      On_Time = sum(is.na(delayed)) / n() * 100,
      Within_15_Minutes = sum(actual - time <= 15) / n() * 100 - On_Time,
      Late = 100 - On_Time - Within_15_Minutes,
      Flights_On_Time = sum(is.na(delayed)),
      Flights_Within_15_Minutes = sum(actual - time <= 15) - Flights_On_Time, 
      Flights_Late = sum(actual - time > 15)
    ) %>%
    pivot_longer(
      cols = c(On_Time, Within_15_Minutes, Late),
      names_to = "Category",
      values_to = "Percentage"
    ) %>%
    pivot_longer(
      cols = starts_with("Flights_"),
      names_to = "Count",
      values_to = "Flights"
    ) %>%
    #filter(!is.na(terminal)) %>%
    mutate(Count = gsub("Flights_", "", Count)) %>%
    filter(Category == Count) %>%
    select(-Count) %>%
    #group_by(terminal) %>%
    mutate(Label = ifelse(Category == "Within_15_Minutes",
                          round(cumsum(Percentage), 0),
                          round(Percentage, 0))
    ) %>%
    ungroup()  # Add this line to remove grouping after calculations
  
  return(percentage_df)
}

# Usage
departure_percentages <- calculate_percentage(departures_dd, "dep")
arrival_percentages <- calculate_percentage(arrivals_dd, "arr")
#percentage_df <- departure_percentages


# Return Donut chart, speedometer style - analyzing performance metrics
stacked_donut <- function(percentage_df, title) {
  
  # Combine "On_Time" and "Within_15_Minutes" categories and calculate sum
  percentage_df <- percentage_df %>%
    mutate(Category = ifelse(Category %in% c("On_Time", "Within_15_Minutes"), "Within_15_Mins", Category)) %>%
    group_by(Category) %>%
    summarise(Percentage = sum(Percentage), Flights = sum(Flights)) %>%
    mutate(Category = factor(Category, levels = c("Within_15_Mins", "Late")))
  
  donut_chart <- ggplot(percentage_df, aes(x = "", y = Percentage, fill = Category)) +
    geom_bar(width = 1, stat = "identity", color = "white") +
    coord_polar("y", start = 0) +
    #geom_text(aes(label = Flights),
    #          position = position_stack(vjust = 0.5),
    #          hjust = 1,
    #          color = "black",
    #          size = 4) +
    scale_fill_manual(values = case_when(
      percentage_df$Percentage[2] > 70 ~ c("#98FB98", "lightgrey"),
      percentage_df$Percentage[2] > 60 ~ c("#FFD700", "lightgrey"),
      TRUE ~ c("#FF8C8C","lightgrey")
    )) +
    labs(title = paste("Percentage of Flight", title, "Within 15 Minutes, and Late"),
         x = NULL, y = NULL) +
    theme_void() +
    geom_polygon(data = data.frame(x = c(-0.1, 0.1), y = c(-Inf, -Inf)), aes(x, y), fill = "white") +
    geom_hline(yintercept = c(40, 30), color = "blue", linetype = "dashed", size = 1) +
    geom_hline(yintercept = 0, color = "black", linetype = "solid", size = 1) +
    geom_text(data = data.frame(y = c(40, 30), label = paste0(" ", c(60, 70), "%")),
              aes(x = 1.75, y = y, label = label),
              inherit.aes = FALSE,
              hjust = 0,
              color = "black",
              size = 4)
  
  print(donut_chart)
}

# Usage
stacked_donut(departure_percentages, "Departures")
stacked_donut(arrival_percentages, "Arrivals")



